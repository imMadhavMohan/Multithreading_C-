#include <iostream>
#include <thread>
using namespace std;

// Using Function Pointer


void printNum(int *arr, int n)
{
    cout<<"Thread is created>>\n";
    int sum=0;
    cout<<"Thread id: "<<this_thread::get_id()<<endl;    
    for (int i = 0; i < n; i++)
    {
        sum += arr[i];
    }   
    cout<<"Sum of all elements: "<<sum<<endl;
    cout << "Thread is terminated>>"<< endl;
}



// whenever you passed the value by refernce always pass it
// using ref(val) to aviod error

int main()
{
    int sum{0}, n = 5;
    int arr[] = {1, 2, 3, 4, 5};    

    thread t; // not a thread    
    thread t1(printNum, arr, n);
    
    t1.join(); // wait for Termination of thread    

    return 0;
}