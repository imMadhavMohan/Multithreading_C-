#include <iostream>
#include <thread>
using namespace std;

void Odd(int n){
    cout<<"\nThread1 is created>>"<<this_thread::get_id()<<endl;    
    for(int i=0;i<=n;i++){
        if(i&1)
            cout<<i<<" ";
    }
    cout<<"\nThread1 is Terminated>>\n"<<endl;
}

void Even(int n){
    cout<<"\nThread2 is created>>"<<this_thread::get_id()<<endl;    
    for(int i=0;i<=n;i++){
        if(!(i&1))
            cout<<i<<" ";
    }
    cout<<"\nThread2 is Terminated>>\n"<<endl;
}

int main()
{
    int n=10;
    thread th1(Odd, n);    
    thread th2(Even, n);

    th1.join();
    // this_thread::sleep_for(chrono::seconds(4));
    th2.join();
    return 0;
}