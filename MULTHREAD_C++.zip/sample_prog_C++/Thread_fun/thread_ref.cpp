#include <iostream>
#include <thread>
using namespace std;

void printNum(int &sum, int *arr, int n, int *ptr)
{
    cout<<"Thread id: "<<this_thread::get_id()<<endl;    
    for (int i = 0; i < n; i++)
    {
        sum += *(i+arr); // *(arr+i) = arr[i]
    }
    cout<<"YOB: "<<*ptr<<endl;    
}



// whenever you passed the value by refernce always pass it
// using ref(val) to aviod error

int main()
{
    int sum{0}, n = 5;
    int arr[] = {1, 2, 3, 4, 5};
    int *ptr = new int(1999);   // DAM

    thread t0; // not a thread
    thread t1(printNum, ref(sum), arr, n, ref(ptr));

    t1.join(); // wait for Termination of thread
    cout << "Sum is: " << sum << endl;

    return 0;
}