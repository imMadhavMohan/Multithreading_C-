#include <iostream>
#include <thread>
using namespace std;

// Using Lambda function

auto Odd = [](int &sum, int n) {
    cout<<"Thread1 is created>> \n";
    for(int i=0;i<=n;i++){
        if(i&1)
            cout<<i<<" ";
        sum+=i;
    }      
    cout<<"Thread1 is exited>> \n";
};

int main(){    
    int n=6, sum=0;    
    thread t1(Odd, ref(sum), n);

    t1.join();
    
    cout<<"Sum is: "<<sum<<'\n';
    return 0;
}