#include <iostream>
#include <thread>
#include <chrono>
using namespace std;
 
void Odd(int n){    
    cout<<"\nThread is created>>"<<this_thread::get_id()<<endl;    
    for(int i=0;i<=n;i++){
        if(i&1)
            cout<<i<<" ";              
    }
    cout<<"\nThread is Terminated>>\n"<<endl;    
}
 
int main()
{
    cout << boolalpha;
    int n=10;    

    thread th=thread(Odd, n);   
    th.detach(); // Allowed thread independently exe

    // this_thread::sleep_for(chrono::milliseconds(5));   

    // this_thread::sleep_for(chrono::milliseconds(3000));    
    cout<<"Thread is joinable: "<<th.joinable()<<endl; // detached thread aren't Joinable                
    return 0;
}