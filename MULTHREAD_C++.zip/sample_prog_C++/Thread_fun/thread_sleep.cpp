#include <iostream>
#include <thread>
#include <chrono>
using namespace std;

void Odd(int n)
{
    auto start = chrono::high_resolution_clock::now();
    this_thread::sleep_for(chrono::seconds(2));  
    cout << "\nThread is created>>" << this_thread::get_id() << endl;
    for (int i = 0; i <= n; i++)
    {
        if (i & 1)
            cout << i << " ";        
    }
    cout << "\nThread is Terminated>>\n"<< endl;
    
    auto end = chrono::high_resolution_clock::now();

    chrono::duration<double, std::milli> elapsed = end - start;    
    cout<<"Time to execute the thread: "<<elapsed.count()<<"ms"<<endl;
}

int main()
{
    cout << boolalpha;
    int n = 10;

    thread th = thread(Odd, n);
    th.detach(); // Allowed thread independently
    
    // th.join(); // Can't join    
    this_thread::sleep_for(chrono::seconds(3));  
    cout << "Thread is joinable: " << th.joinable() << endl; // detached thread aren't Joinable    

    return 0;
}