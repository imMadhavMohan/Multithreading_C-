#include <iostream>
#include <thread>
#include <chrono>
using namespace std;
 
void Odd(int n){
    cout<<"\nThread is created>>"<<this_thread::get_id()<<endl;    
    for(int i=0;i<=n;i++){
        if(i&1)
            cout<<i<<" ";
        this_thread::sleep_for(chrono::milliseconds(1000));
    }
    cout<<"\nThread is Terminated>>\n"<<endl;
}
 
int main()
{
    cout << boolalpha;
    int n=10;
    thread th;  // Default constructed
    cout<<"Default constructed: "<<th.joinable()<<endl;

    th=thread(Odd, n);
    
    if(th.joinable()){
        cout<<"Thread is still running: ";
        th.join();
    }
    else {
        cout<<"Thread is no longer running: ";
    }
    
    cout<<"Thread is running: "<<th.joinable()<<endl; // not joinable 
    return 0;
}