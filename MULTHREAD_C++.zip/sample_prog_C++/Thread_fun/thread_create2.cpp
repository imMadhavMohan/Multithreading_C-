#include <iostream>
#include <thread>
using namespace std;

// Using Function obj

class Odd{
    public:
        void operator()(int n, int &sum){
            cout<<"\nThread is created>>"<<this_thread::get_id()<<endl;    
            for(int i=0;i<=n;i++){
                if(i&1)
                    cout<<i<<" ";
                sum+=i;
            }
        }
};


int main()
{
    int n=10;
    int sum=0;
    thread th1((Odd()), n, ref(sum));    

    th1.join();
    cout<<"Sum is: "<<sum<<'\n';
    return 0;
}