#include <iostream>
#include <thread>
using namespace std;

void Odd(int n){
    cout<<"\nThread is created>>"<<this_thread::get_id()<<endl;    
    for(int i=0;i<=n;i++){
        if(i&1)
            cout<<i<<" ";
    }
    cout<<"\nThread is Terminated>>\n"<<endl;
}

int main()
{
    int n=10;
    thread th1(Odd, n);
    thread th2(move(th1));

    // th1.join();  // no longer a thread so no need to join
    th2.join();
    return 0;
}