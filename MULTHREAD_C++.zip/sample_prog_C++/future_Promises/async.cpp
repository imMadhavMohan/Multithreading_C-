#include <iostream>
#include <thread>
#include <chrono>
#include <future>

typedef long int ull;

using namespace std;

ull evenSum(ull start, ull end, ull sum)
{ // returning value
    this_thread::sleep_for(chrono::seconds(1));

    cout << "\nAsync thread begins execution>>> " << endl; // New thread is begin
    cout << "\nAsync thread id: " << this_thread::get_id() << endl;
    for (ull i = start; i <= end; i++)
        if (!(i & 1))
            sum += i;

    cout << "\nAsync thread ends execution>>> " << endl;

    return sum;
}

int main()
{
    ull start = 3, end = 1800000000, sum = 0;
    cout << "Main thread begins >>> " << endl;
    cout << "Main thread id: " << this_thread::get_id() << endl;
    future<ull> EvenSum = async(launch::async, evenSum, start, end, sum);

    // sum = EvenSum.get();    // dont use twice

    if (EvenSum.valid())
    {
        sum = EvenSum.get();
        cout << "\nSum is: " << sum << endl;
    }
    else
        cout << "\nInvalid Operation" << endl;

    cout << "\nSum is: " << sum << endl;

    cout << "\nMain thread ends >>> " << endl; // Main thread is waiting

    return 0;
}