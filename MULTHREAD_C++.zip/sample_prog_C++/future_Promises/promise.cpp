#include <iostream>
#include <thread>
#include <chrono>
#include <future>

typedef long int ull;

using namespace std;

void oddSum(promise<ull> pr, ull start, ull end)
{ 
    this_thread::sleep_for(chrono::seconds(1));
    ull sum = 0;

    cout << "\nAsync thread begins>>> " << endl;
    cout << "\nAsync thread id: " << this_thread::get_id() << endl;
    for (ull i = start; i <= end; i++)
        if ((i & 1))
            sum += i;

    cout << "\nAsync thread ends>>> " << endl;
    this_thread::sleep_for(chrono::seconds(10));  
      
    pr.set_value(sum);        
}

int main()
{
    ull start = 3, end = 1900000000, sum = 0;

    promise<ull> pr; // promise obj created

    cout << "\nMain thread begins >>> " << endl;
    cout << "\nMain thread id: " << this_thread::get_id() << endl;
    future<ull> OddSum = pr.get_future();

    thread th(oddSum, move(pr), ref(start), ref(end));

    sum = OddSum.get();
    cout << "\nSum is: " << sum << endl;

    if(th.joinable())
        th.join();
    else 
        cout<<"\nNot Joinable"<<endl;

    cout << "\nMain thread ends>>> " << endl; // Main thread is waiting

    return 0;
}