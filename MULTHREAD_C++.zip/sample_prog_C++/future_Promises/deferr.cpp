#include <iostream>
#include <thread>
#include <chrono>
#include <future>

typedef long int ull;

using namespace std;

ull evenSum(ull start, ull end, ull sum)
{ // returning value
    this_thread::sleep_for(chrono::seconds(1));

    cout << "\nAsync thread begins>>> " << endl;
    cout << "\nAsync thread id: " << this_thread::get_id() << endl;
    for (ull i = start; i <= end; i++)
        if (!(i & 1))
            sum += i;

    cout << "\nAsync thread ends>>> " << endl;

    return sum;
}

int main()
{
    ull start = 0, end = 1900000000, sum = 0;

    cout << "Main thread begins >>> " << endl;
    cout << "Main thread id: " << this_thread::get_id() << endl;
    future<ull> EvenSum = async(launch::deferred, evenSum, start, end, sum);

    sum = EvenSum.get();
    cout << "\nSum is: " << sum << endl;

    cout << "\nMain thread ends >>> " << endl; // Main thread is waiting

    return 0;
}