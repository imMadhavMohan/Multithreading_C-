#include<iostream>
#include<thread>
#include<mutex>
#include<chrono>
#include<condition_variable>

using namespace std;

// Producer consumer

condition_variable cv;
mutex mtx;
long balance=0;

void addMoney(int money){
    lock_guard<mutex> lg(mtx);
    balance+=money;
    cout<<"Amount added! Current Balance is: "<<balance<<endl;
    cv.notify_one(); 

}

void withdrawMoney(int money){
    unique_lock<mutex> ul(mtx);
    cv.wait(ul, []{return (balance!=0)?true:false;});
    if(balance>=money){
        balance-=money;
        cout<<"Amount Deducted: "<<money<<endl;
    }else{
        cout<<"Amount can't be Deducted, Current Balance is Less than "<<money<<endl;
    }   
    cout<<"Current Balance Is: " <<balance<<endl;
}    

int main(){
    thread t1(withdrawMoney, 200);        

    thread t2(addMoney, 500);

    t1.join();
    t2.join();
    return 0;
}