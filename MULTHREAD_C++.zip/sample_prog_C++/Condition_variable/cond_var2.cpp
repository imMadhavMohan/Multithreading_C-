#include <iostream>
#include <thread>
#include <chrono>
#include <condition_variable> 

using namespace std;

condition_variable produce;
mutex mtx;
condition_variable consume;

int meal = 0;     // shared value by producers and consumers

void consumer (int id) {
  unique_lock<mutex> lck(mtx);

  this_thread::sleep_for(chrono::seconds(1));
  
  while (meal==0) 
    consume.wait(lck);

  cout <<"Thread-"<<"{"<<id<<"} is consuming"<<": "<<meal <<endl;
  meal=0;
  produce.notify_one();
}

void producer (int id) {
  unique_lock<mutex> lck(mtx);

  this_thread::sleep_for(chrono::seconds(1));

  while (meal!=0) 
    produce.wait(lck);

  meal = id;
  consume.notify_one();
}

int main ()
{
  thread consumers[10],producers[10];
  
  for (int i=1; i<=10; ++i) {    
    consumers[i] = thread(consumer,i);
    producers[i] = thread(producer,i);
  }

  // join them back:
  for (int i=1; i<=10; ++i) {
    producers[i].join();
    consumers[i].join();
  }

  return 0;
}