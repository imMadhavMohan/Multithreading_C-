#include<iostream>
#include<thread>
#include<mutex>
#include<chrono>

using namespace std;
mutex mtx;

static int glob = 0;

void threadFunc1()
{
    int loc;
    int loop = 500000;
    // mtx.lock();
    cout<<"\nThread-1 Begins>>\n";
    cout<<"     Critical section is in Progress>>..."<<endl;
    for (int i = 0; i < loop; i++) {
        loc = glob;
        loc++;
        glob = loc;        
        }
    cout<<"Thread-1 Exits>>\n";
    // mtx.unlock();
}

void threadFunc2()
{
    int loc;
    int loop = 500000;
    // mtx.lock();
    cout<<"\nThread-2 Begins>>\n";
    cout<<"     Critical section is in Progress>>..."<<endl;
    for (int i = 0; i < loop; i++) {
        loc = glob;
        loc++;
        glob = loc;        
    }
    cout<<"Thread-2 Exits>>\n";
    // mtx.unlock();
}

int main()
{
    thread t1(threadFunc1);
    
    thread t2(threadFunc2);    
    
    this_thread::sleep_for(chrono::seconds(3));

    if(t1.joinable())    
        t1.join();
    if(t2.joinable())
        t2.join();

    cout<<"\nShared Resource Result>> "<<glob<<endl;
    return 0;    
}
