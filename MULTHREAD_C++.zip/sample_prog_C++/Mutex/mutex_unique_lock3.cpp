#include<iostream>
#include<thread>
#include<mutex>
#include<chrono>

using namespace std;
mutex mtx;

static int glob = 0;

void Even(int n){  
    cout<<endl;  
    for(int i=0;i<=n;i++)
        if(!(i&1))
            cout<<i<<" ";
    cout<<endl;
}

void fun1(const char* arg, int n)
{
    int loc;
    int loop = n;
    bool flag1=true;
    bool flag2=true;
    unique_lock<mutex> lock(mtx, defer_lock);  // not acquire at this point    
    
    while(flag1){
        if(mtx.try_lock()){     // trying acquire lock
            cout<<"\n"<<arg <<" Begins>>\n";
            cout<<"     Critical section is in Progress>>..."<<endl;
            for (int i = 0; i < loop; i++) {
                loc = glob;
                loc++;
                glob = loc;  
                cout<<arg<<" "<<i<<endl;     
            }
        cout<<"     Critical section Exited>>..."<<endl;

        mtx.unlock();
        flag1=false;
        }
        else{
            if(flag2){
            cout<<endl<<arg<<" is waiting to acquire lock";
            Even(n); // task
            flag2=false;
        }
    }
    }
    cout<<arg <<" Exited>>\n";         
}

int main()
{
    thread t1(fun1, "T1 thread", 10);
    
    thread t2(fun1, "T2 thred", 12);    
    
    this_thread::sleep_for(chrono::seconds(4));

    if(t1.joinable())    
        t1.join();
    if(t2.joinable())
        t2.join();

    cout<<"\nShared Resource Result>> "<<glob<<endl;
    return 0;    
}
