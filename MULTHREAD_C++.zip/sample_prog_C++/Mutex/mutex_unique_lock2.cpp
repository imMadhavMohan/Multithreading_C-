#include<iostream>
#include<thread>
#include<mutex>
#include<chrono>

using namespace std;
mutex mtx;

static int glob = 0;

void fun1(const char* arg, int n)
{
    int loc;
    int loop = n;
 
    unique_lock<mutex> lock(mtx);
    // mtx.lock();
    
    cout<<"\n"<<arg <<" Begins>>\n";
    cout<<"     Critical section is in Progress>>..."<<endl;
    for (int i = 0; i < loop; i++) {
        loc = glob;
        loc++;
        glob = loc;  
        cout<<arg<<" "<<i<<endl;     
        }
    cout<<"     Critical section Exited>>..."<<endl;

    // mtx.unlock();
    cout<<arg <<" Exited>>\n";         
}

int main()
{
    thread t1(fun1, "T1 thread", 10);
    
    thread t2(fun1, "T2 thred", 10);    
    
    this_thread::sleep_for(chrono::seconds(2));

    if(t1.joinable())    
        t1.join();
    if(t2.joinable())
        t2.join();

    cout<<"\nShared Resource Result>> "<<glob<<endl;
    return 0;    
}
