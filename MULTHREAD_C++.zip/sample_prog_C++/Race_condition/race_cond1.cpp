#include<iostream>
#include<thread>
#include<mutex>
#include<chrono>

// Mutual Exclusion

using namespace std;
int balance{0};
mutex mtx;

int read_balance(){
    this_thread::sleep_for(chrono::seconds(1));
    return balance;
}

void write_balance(int current_balance){
    this_thread::sleep_for(chrono::seconds(1));
    balance=current_balance;
}

void deposit(int amount){
    mtx.lock();    // show
    
    int account_balance = read_balance();    
    account_balance += amount;     
    write_balance(account_balance);

    mtx.unlock();
}

int main(){
    thread th1(deposit, 2000);
    thread th2(deposit, 3000);
    
    if(th1.joinable())
        th1.join();

    if(th2.joinable())
        th2.join();

    cout<<"current_Amount: "<<balance<<endl;
    return 0;
}