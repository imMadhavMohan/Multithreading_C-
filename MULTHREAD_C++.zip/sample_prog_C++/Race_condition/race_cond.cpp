#include<iostream>
#include<thread>
#include<mutex>

// Mutual Exclusion

using namespace std;

mutex mtx;
int cnt{0};

void increment(const char* str){
    // mtx.lock();
    cout<<str<<" Critical section begins>> ";
    cnt++;
    // this_thread::sleep_for(chrono::seconds(1));
    cout<<endl<<"cnt_val is: "<<cnt<<endl;
    cout<<str<<" Critical section Exited>> "<<endl<<endl;
    // mtx.unlock();
}

int main(){
    thread th1(increment, "Th1");
    thread th2(increment, "Th2");
    thread th3(increment, "Th3");

    th1.join();
    th2.join();
    th3.join();
    return 0;
}