#include <iostream>
#include <thread>
#include <semaphore>
#include <vector>

// Go to this website https://coliru.stacked-crooked.com/
// to compile this code as GCC 20.01 isn't available officially

using namespace std;

counting_semaphore<10> semph(5);
int gvar{0};

void fun(int id)
{
  semph.acquire(); // wait
  cout << "Critical section Begins for thread>>" << id << endl;
  for (int i = 0; i < 5; i++)
    gvar++;
  cout << "   Critical section Executing>>..." << endl;
  cout << "Critical section Ends for thread>>" << id << endl;
  semph.release(); // signal
  cout << endl;
}

int main()
{
  vector<thread> vectorOfth;

  for (int i = 0; i < 5; i++)
  {
    thread th = thread(fun, i);
    vectorOfth.push_back(move(th));
    this_thread::sleep_for(chrono::seconds(1));
  }

  for (thread &th : vectorOfth)
  {
    if (th.joinable())
      th.join();
  }

  cout << "Final value Gvar: " << gvar << endl;

  return 0;
}