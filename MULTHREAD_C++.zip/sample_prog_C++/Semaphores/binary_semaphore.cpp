#include <iostream>
#include <thread>
#include <chrono>
#include <semaphore>

// Go to this website https://coliru.stacked-crooked.com/
// to compile this code as GCC 20.01 isn't available officially

using namespace std;
int gvar{0};

binary_semaphore semph{1};

void fun(int id)
{
    semph.acquire(); // wait
    cout << "Critical section Begins for thread>>" << id << endl;
    for (int i = 0; i < 5; i++)
        gvar++;
    cout << "   Critical section Executing>>..." << endl;
    cout << "Critical section Ends for thread>>" << id << endl;
    this_thread::sleep_for(chrono::seconds(1));
    semph.release(); // signal
    cout << endl;
}

int main()
{
    thread th1(fun, 1);
    thread th2(fun, 2);

    th1.join();
    th2.join();

    cout << "Final val of Gvar: " << gvar << endl;

    return 0;
}