#include <iostream>
#include <thread>
#include <mutex>
#include <chrono>

using namespace std;
int x{0};
int y{0};

mutex xMtx;
mutex yMtx;

void x_Increment_y(){    
    yMtx.lock();
    xMtx.lock();
    this_thread::sleep_for(chrono::seconds(1));
    // yMtx.lock();

    cout<<"\nCritical-1 Section Begins>>"<<endl;
    x++;
    y++;
    
    cout<<"Critical-1 is progressing>>>"<<endl;

    xMtx.unlock();
    yMtx.unlock();
    cout<<"Critical-1 Section ends>>"<<endl;
}

void y_Increment_x(){
    yMtx.lock();
    this_thread::sleep_for(chrono::seconds(1));
    xMtx.lock();    

    cout<<"\nCritical-2 Section Begins>>"<<endl;
    y++;
    x++;

    cout<<"Critical-2 is progressing>>>"<<endl;

    yMtx.unlock();
    xMtx.unlock();
    cout<<"Critical-2 Section ends>>"<<endl;
}


int main(){
    thread th1(x_Increment_y);
    thread th2(y_Increment_x);

    th1.join();
    th2.join();

    return 0;
}