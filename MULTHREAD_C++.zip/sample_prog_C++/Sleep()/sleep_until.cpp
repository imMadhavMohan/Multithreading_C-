#include <iostream>
#include <thread>
#include <chrono>
using namespace std;

void Odd(int n,chrono::system_clock::time_point timePt)
{
    auto start = chrono::high_resolution_clock::now();

    this_thread::sleep_until(timePt + chrono::seconds(2));  
    cout << "\nThread is created>>" << this_thread::get_id() << endl;
    for (int i = 0; i <= n; i++)    
        if (i & 1)
            cout << i << " ";            
    cout <<"\nThread is Terminated>>\n"<< endl;
    
    auto end = chrono::high_resolution_clock::now();

    chrono::duration<double, std::milli> elapsed = end - start;    
    cout<<"Time to execute the thread: "<<elapsed.count()<<"ms"<<endl;
}

int main()
{
    cout << boolalpha;
    int n = 10;
    chrono::system_clock::time_point timePt = chrono::system_clock::now() + chrono::seconds(2);
    thread th = thread(Odd, n, ref(timePt));
    th.detach(); // Allowed thread independently
    
    // th.join(); // Can't join    
    this_thread::sleep_for(chrono::seconds(5));  
    cout << "Thread is joinable: " << th.joinable() << endl; // detached thread aren't Joinable    

    return 0;
}